# Sakan Consulting - Website

Static website with 4 pages: Home, Solutions, Services, About Us.

## Files
- `index.html` - Home
- `solutions.html`, `services.html`, `about-us.html`
- `support.js` - page runtime (required - keep it next to the HTML files)
- `assets/` - logo

Fonts, icons and photos load from the internet (Google Fonts, Lucide, Unsplash), so an internet connection is needed.

## Preview locally
Open `index.html` in a browser, or run a local server in this folder:
```
npx serve .
```

## Push to GitHub
```
git init
git add .
git commit -m "Sakan Consulting website"
git branch -M main
git remote add origin https://github.com/<your-username>/sakan-website.git
git push -u origin main
```
(Or on github.com: New repository -> Add file -> Upload files -> drag in everything from this folder -> Commit.)

## Publish with GitHub Pages
Repository -> Settings -> Pages -> Source: Deploy from a branch -> Branch: `main`, folder `/ (root)` -> Save.
The site goes live at `https://<your-username>.github.io/sakan-website/`.
